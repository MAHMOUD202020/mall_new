<?php

namespace Database\Seeders;

use App\Models\Section;
use App\Models\Slider;
use Illuminate\Database\Seeder;

class SliderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($x= 0 ; $x<= 150; $x++){

            Slider::create([
                'src' => random_int(1 , 7).'jpg',
                'type' => 'img',
                'sort' => random_int(1 , 7),
                'section_id' => Section::inRandomOrder()->first()->id
            ]);
        }
    }
}
